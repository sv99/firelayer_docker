<script>
export default {
  data(){
    return {step: 1}
  }
}

</script>
<template>

<span style="height:8px;width:36px;"><span class="loader-box"></span><span class="loader-box"></span><span class="loader-box"></span></span>

</template>
