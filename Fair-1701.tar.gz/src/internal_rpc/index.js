// Internal RPC serves requests made by the user's browser or by the merchant server app
module.exports = require('./handler')
