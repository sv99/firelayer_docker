module.exports = (args) => {
  me.batchAdd('cancelOrder', args.id)
  return {}
}
