// External RPC processes requests to our node coming from outside world.
// Also implements validator and hub functionality
module.exports = require('./handler')
